//export let keyValue = 1000;
//export let test =()=>console.log('test()');

let keyValue = 1000;
let test = () => {
  keyValue += 1000;
  return keyValue

};
let ab = 'some text';

export default ab;
export {keyValue, test};