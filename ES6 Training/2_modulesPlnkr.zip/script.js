// Code goes here
import * as imported from 'external.js';
//import ab, {keyValue as key, test} from './external.js';
// import ab from './external.js';
//import {test} from './external.js';

//console.log(ab);
//console.log(key);
//console.log(test());

console.log(imported);
